// serve.mjs: node serve.mjs <variant> [--port 4390] [--dir dist]
// Serves dist/<variant>/ on 127.0.0.1 only (for `tailscale serve` to publish on the tailnet). Static files, GET only; a build that holds
// the inbox plugin also gets the Inbox API (scripts/inbox-api.mjs), and one that holds the files plugin gets the Files API
// (scripts/files-api.mjs); both answer only a loopback Host.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync, readFileSync, realpathSync } from 'node:fs';
import { join, extname, resolve, sep, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png' };

// `api` is optional: async (req, res, url) => true when it answered, with an optional .decorate(req, indexHtml) -> indexHtml.
// The CLI passes the Inbox API only for a build that holds the inbox plugin.
export function serve(dir, port = 0, api = null) {
  const base = resolve(dir);
  const server = createServer(async (req, res) => {
    let url, rel;
    try {
      url = new URL(req.url, 'http://localhost');
      if (api && await api(req, res, url)) return;
      rel = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
    } catch { if (!res.headersSent) res.writeHead(400).end('bad request'); return; }   // a malformed address (/%E0%A4%A) is a 400, never a crash
    const file = resolve(join(base, rel));
    if (req.method !== 'GET' || (file !== base && !file.startsWith(base + sep))) { res.writeHead(404).end('not found'); return; }
    try {
      let body = await readFile(file);
      if (api && api.decorate && file === join(base, 'index.html')) body = api.decorate(req, body);   // tells the page the API is there, so a plain static server is never probed
      res.writeHead(200, { 'content-type': TYPES[extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' }).end(body);
    } catch  { res.writeHead(404).end('not found'); }
  });
  return new Promise((ok) => server.listen(port, '127.0.0.1', () => ok(server)));
}

// Several APIs as one: the first that answers wins, and each one's page marker is added in turn.
export function composeApis(apis) {
  return Object.assign(async (req, res, url) => { for (const a of apis) if (await a(req, res, url)) return true; return false; },
    { decorate: (req, html) => apis.reduce((h, a) => (a.decorate ? a.decorate(req, h) : h), html) });
}

// realpath on both sides: a folder reached through a symlink (/tmp on a Mac, a linked home) must still start, not exit without a word
if (process.argv[1] && realpathSync(resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url))) {
  const arg = (k) => { const i = process.argv.indexOf(k); return i > 0 ? process.argv[i + 1] : undefined; };
  const variant = process.argv[2];
  if (!variant || variant.startsWith('--')) { console.error('usage: node serve.mjs <variant> [--port 4390] [--dir dist]'); process.exit(2); }
  const dir = join(arg('--dir') || join(dirname(fileURLToPath(import.meta.url)), 'dist'), variant);
  const here = dirname(fileURLToPath(import.meta.url));
  // add feed, find feeds, capture and compaction exist only where the inbox plugin does, and never in a reader build (it makes no outside request)
  const reader = existsSync(join(dir, 'plugins/inbox/data.js')) && readFileSync(join(dir, 'plugins/inbox/data.js'), 'utf8').includes('"reader":true');
  const inbox = existsSync(join(dir, 'plugins/inbox')) && !reader && existsSync(join(here, 'scripts/inbox-api.mjs'));
  const files = existsSync(join(dir, 'plugins/files')) && existsSync(join(here, 'scripts/files-api.mjs'));   // the file tree, reading and editing exist only where the files plugin does
  const apis = [];
  if (files) apis.push((await import('./scripts/files-api.mjs')).createFilesApi());   // first: the inbox API answers every other /api/* path
  if (inbox) apis.push((await import('./scripts/inbox-api.mjs')).createInboxApi());
  const api = apis.length ? composeApis(apis) : null;
  const server = await serve(dir, Number(arg('--port') || 4390), api);
  console.log(`serving ${variant} on http://127.0.0.1:${server.address().port}/${inbox ? ' (with the inbox API)' : ''}${files ? ' (with the files API)' : ''}`);
}
