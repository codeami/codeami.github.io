#!/bin/sh
# setup.sh: installs Broman OS (trial) into ONE folder, ~/BromanOS (or $BROMANOS_HOME). Run it from the unzipped folder.
#   sh setup.sh              check, verify the checksums, then copy. Refuses to overwrite an existing install.
#   sh setup.sh uninstall    remove that one folder (only if this script made it)
# It needs no admin rights and refuses to run as root. It writes nothing outside the install folder, installs no software,
# and makes no network request. Mac, Linux, and Windows through WSL (Ubuntu): on Windows run it inside the WSL terminal.
set -eu

HERE="$(cd "$(dirname "$0")" && pwd)"
TARGET="${BROMANOS_HOME:-$HOME/BromanOS}"
PORT="${BROMANOS_PORT:-4571}"
MARK=".broman-os-trial"

say() { printf '%s\n' "$*"; }
stop() { printf 'Stopped: %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -ne 0 ] || stop "do not run this as root or with sudo. It does not need it."

if [ "${1:-}" = "uninstall" ]; then
  [ -d "$TARGET" ] || stop "nothing to remove: $TARGET does not exist."
  [ -f "$TARGET/$MARK" ] || stop "$TARGET was not made by this setup (no $MARK file), so it is left alone."
  rm -rf "$TARGET"
  say "Removed $TARGET. Nothing else was touched."
  exit 0
fi
[ -z "${1:-}" ] || stop "unknown option '$1'. Use: sh setup.sh   or   sh setup.sh uninstall"

say "Checking this computer..."
# Windows: this runs inside WSL, a Linux that Windows can host. Keep the install on the Linux side (slow and odd permissions under /mnt/c).
WSL=0
if [ -r /proc/version ] && grep -qi microsoft /proc/version 2>/dev/null; then WSL=1; say "Windows (WSL) detected."; fi
case "$TARGET" in /mnt/*) stop "$TARGET is on the Windows drive. Use a folder on the Linux side, such as ~/BromanOS. Nothing was changed." ;; esac
command -v node >/dev/null 2>&1 || stop "Node is not installed. This needs Node 24 or newer. Install it yourself from nodejs.org, then run this again. Nothing was changed."
NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
[ "$NODE_MAJOR" -ge 24 ] || stop "Node $NODE_MAJOR is too old; this needs Node 24 or newer. Nothing was changed."
if command -v shasum >/dev/null 2>&1; then SUM="shasum -a 256"; elif command -v sha256sum >/dev/null 2>&1; then SUM="sha256sum"; else stop "no shasum or sha256sum found, so the files cannot be checked. Nothing was changed."; fi
[ ! -e "$TARGET" ] || stop "$TARGET already exists. Setup will not overwrite it. Run 'sh setup.sh uninstall' first if you want to start again."

say "Checking the files against CHECKSUMS.sha256..."
[ -f "$HERE/CHECKSUMS.sha256" ] || stop "CHECKSUMS.sha256 is missing, so the files cannot be checked. Nothing was copied."
( cd "$HERE" && $SUM -c CHECKSUMS.sha256 >/dev/null 2>&1 ) || stop "a file does not match CHECKSUMS.sha256. The package may be damaged or changed. Nothing was copied."
say "All files match."

# copy into a working folder next to the target, then move it into place, so a half install is never left behind
PARENT="$(dirname "$TARGET")"
[ -d "$PARENT" ] && [ -w "$PARENT" ] || stop "cannot write to $PARENT. Nothing was changed."
WORK="$TARGET.setup.$$"
trap 'rm -rf "$WORK"' EXIT
mkdir "$WORK"
cp -R "$HERE/app" "$WORK/app"
cp "$HERE/serve.mjs" "$WORK/serve.mjs"
cp "$HERE/INSTALL-WITH-YOUR-AI.md" "$WORK/INSTALL-WITH-YOUR-AI.md"
cat > "$WORK/start.sh" <<'EOF'
#!/bin/sh
# Starts Broman OS on this computer only (127.0.0.1). Press Ctrl-C to stop. Change the port with BROMANOS_PORT.
HERE="$(cd "$(dirname "$0")" && pwd)"
exec node "$HERE/serve.mjs" trial --dir "$HERE/app" --port "${BROMANOS_PORT:-4571}"
EOF
chmod +x "$WORK/start.sh"
: > "$WORK/$MARK"
mv "$WORK" "$TARGET"
trap - EXIT

say ""
say "Done. What this did:"
say "  - checked Node $(node -v) and the checksums"
say "  - made one folder: $TARGET"
say "  - copied the app, the local server, start.sh and these instructions into it"
say "  - changed nothing else, installed nothing, sent nothing"
say ""
say "Next: run   $TARGET/start.sh"
say "Then open:  http://127.0.0.1:$PORT/"
[ "$WSL" -eq 0 ] || say "(On Windows, open that address in your normal Windows browser. WSL passes localhost through.)"
say "To remove it later: sh setup.sh uninstall"
