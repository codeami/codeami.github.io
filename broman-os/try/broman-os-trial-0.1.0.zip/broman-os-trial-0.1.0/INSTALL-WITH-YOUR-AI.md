# Install Broman OS (trial) with your AI assistant

**To the person:** open your AI assistant (one that can run commands on your computer), give it this file, and say: "Follow INSTALL-WITH-YOUR-AI.md."

**To the assistant:** follow these steps in order. Stop and tell the person if any step fails. Do not try workarounds.

## Rules

- Do not use `sudo` or ask for an admin password. Setup itself needs none. (On Windows, turning on WSL is the one step that needs an admin, and only the person may do it. See "Windows".)
- Do not ask the person for a password, key or login. Broman OS never needs one.
- Touch only the folder `~/BromanOS`. Do not install, update or change any other software, except Node 24 when the person says yes (steps below).
- Do not open any web address except `http://127.0.0.1:4571/`. Do not upload, send or share any file.
- If a step says stop, stop. Report what you saw.

## Steps (Mac and Linux)

On Windows, do the "Windows" section first, then come back to step 1 inside the WSL terminal.

1. **Check the zip.** The download page shows a SHA-256 checksum next to the zip (the `.sha256` file has the same line). Run `shasum -a 256 <the zip file>` and show both. If they differ, stop: the file may have changed.
2. **Check Node.** Run `node -v`. It must be v24 or newer. If it is missing or older, stop and tell the person to install Node 24 from nodejs.org. Do not install it yourself.
3. **Unzip** the zip into a new, empty folder, for example `~/Downloads/broman-os-install`.
4. **Run setup** from inside the unzipped folder: `sh setup.sh`. It checks the files against `CHECKSUMS.sha256`, makes `~/BromanOS`, and prints what it did. If it says `Stopped:`, read the reason to the person and stop. It will not overwrite an existing install.
5. **Start it** in the background: `~/BromanOS/start.sh`. It listens on this computer only, on port 4571. If the port is busy, run it with `BROMANOS_PORT=4572 ~/BromanOS/start.sh` and use that port below.
6. **Open the page**: `http://127.0.0.1:4571/`. Tell the person to start at "Start here". The small robot, Bosun, guides them.
7. **Report** to the person: what was installed, where, and the address. Say that nothing was sent anywhere.

## Windows (10 or 11)

Broman OS runs inside WSL (Windows Subsystem for Linux, with Ubuntu). The page then opens in the normal Windows browser at `http://127.0.0.1:4571/`, because WSL passes localhost through. Nothing is installed on the Windows side.

1. **Is WSL there?** In PowerShell run `wsl --status`. If it prints a default distribution (Ubuntu), skip to step 3.
2. **If WSL is missing.** Tell the person plainly: turning it on needs an **administrator** and a **restart** of the computer. The assistant must not do this by itself. The person opens PowerShell as Administrator (right-click, Run as administrator), runs `wsl --install -d Ubuntu`, restarts when asked, then opens "Ubuntu" from the Start menu once and picks a Linux username and password. That password is for Ubuntu only. The assistant must never ask for it or see it. Then continue.
3. **Work inside Ubuntu.** From here, every command runs in the Ubuntu terminal (type `wsl` in PowerShell). Run `uname -a`: it should mention "microsoft".
4. **Node 24 in Ubuntu.** Run `node -v`. It must be v24 or newer. Ubuntu's own package is usually older. If it is missing or older, ask the person: "May I install Node 24 inside Ubuntu only? It does not touch Windows." If yes, download the Linux tarball from nodejs.org and unpack it into `~/.local/node` (no admin needed), and add its `bin` folder to `PATH` in `~/.profile`. If no, stop.
5. **Get the zip into Ubuntu.** If the zip is in Windows Downloads, copy it to the Linux side: `cp /mnt/c/Users/<windows-name>/Downloads/<the zip file> ~/`. Install and unzip on the Linux side, not under `/mnt/c` (setup refuses a folder on the Windows drive).
6. **Check the zip** the same way as step 1 above, with `sha256sum <the zip file>`.
7. Continue with steps 3 to 7 above, inside Ubuntu. The address is opened in the **Windows** browser.

If the page does not open in the Windows browser: in the Ubuntu terminal run `curl -sI http://127.0.0.1:4571/ | head -1`. If that works but Windows cannot reach it, tell the person; do not change network settings.

## Good to know

- It is a free trial with small limits. When one is reached, the page shows an optional "Connect with Troupe for help" button. It shows the exact text first and opens an email draft that you or the person can edit or close. The page sends nothing itself.
- The Workflows page shows the sample workflows. The builder tools on it are locked in this trial.
- The counters live in the browser, for the address `127.0.0.1:4571`. Use the same address each time.
- To remove it: `sh setup.sh uninstall` from the unzipped folder. It deletes only `~/BromanOS`. It does not remove WSL or Node.
